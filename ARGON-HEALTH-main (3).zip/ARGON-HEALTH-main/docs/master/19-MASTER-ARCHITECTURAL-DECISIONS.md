# 19 — MASTER ARCHITECTURAL DECISIONS

STATUS: PROPOSED
EVIDENCE CLASS: DESIGN

## Status
TARGET ARCHITECTURE / PROPOSED. This document is an index of decisions
already made (and justified) inline across `01`–`18`; it does not
introduce new decisions.

## Purpose
Consolidate every major architectural decision made across this
foundation into one browsable ADR log, in standard lightweight ADR format
(Title, Status, Context, Decision, Consequences), so a future contributor
doesn't have to re-derive *why* by reading every document in full.

## Scope
Covers decisions with platform-wide consequence. Domain-local choices
(e.g., a specific field on a specific entity) are not elevated to ADR
status.

## Current Assumptions
An ADR here is Proposed until independently reviewed/accepted by whoever
owns that decision authority for the project — this document does not
self-approve its own entries.

## Evidence
UNKNOWN — REQUIRES EVIDENCE (see `01`).

## Decision — The ADR Log

**ADR-001 — Three-plane model (Control / Application / Data)**
Status: Proposed. Context: needed a top-level decomposition that keeps
platform-management privilege structurally separate from clinical access.
Decision: adopt Control/Application/Data planes + Interoperability
boundary (`01`). Consequences: every subsequent domain/workflow must
declare its plane; enables independent scaling and independent
maintenance windows per plane.

**ADR-002 — Modular monolith first, not microservices-per-domain**
Status: Proposed. Context: no evidence yet of independent-scaling need
per domain. Decision: Spring Modulith-enforced module boundaries within a
small number of Cloud Run services (`13`, `14`). Consequences: lower
initial operational complexity; a future service split is possible
because domain boundaries (`03`) are already drawn correctly.

**ADR-003 — Cloud Run over Kubernetes**
Status: Proposed. Context: no measured load pattern justifies cluster
management overhead. Decision: Cloud Run for both planes (`13`).
Consequences: revisit only on measured autoscaling-ceiling evidence.

**ADR-004 — PostgreSQL as sole structural source of truth**
Status: Proposed. Context: needed one unambiguous system of record.
Decision: PostgreSQL for all structured data; Redis/object storage/search/
warehouse are all derived or binary-only (`04`). Consequences: any
future "let's just read from cache" shortcut is a documented anti-pattern.

**ADR-005 — DICOM/large binaries never in PostgreSQL**
Status: Proposed. Context: relational stores degrade badly under large
binary load. Decision: object storage only for DICOM instances and
documents (`04`, `13`). Consequences: Radiology domain's report/metadata
stays relational; image bytes never touch backup/restore paths meant for
OLTP data.

**ADR-006 — Single Interoperability Layer for all external integration**
Status: Proposed. Context: avoids N duplicated protocol handlers across
domains. Decision: FHIR/HL7/DICOM/IHE/Government/Payer integration all
route through one layer (`06`). Consequences: adding a country or payer
is a plugin, never a Core-domain code change.

**ADR-007 — Three-layer authorization enforcement**
Status: Proposed. Context: a single-layer permission check is a single
point of failure. Decision: application + Authorization Service +
PostgreSQL RLS, all three enforced simultaneously (`07`). Consequences:
an application bug alone cannot cause a cross-tenant data leak if RLS is
correctly configured.

**ADR-008 — Structural separation of Control Plane and Clinical Data
access**
Status: Proposed. Context: platform operators must be able to manage
tenants without implicit PHI access. Decision: distinct privilege
domains, break-glass-only PHI access for Control Plane actors (`07`,
`09`). Consequences: every "support needs to see patient data" request
becomes an audited, time-boxed exception, never a standing permission.

**ADR-009 — Compliance status can never skip IMPLEMENTED → APPROVED**
Status: Proposed. Context: prevents "we built it" from being read as "an
auditor approved it." Decision: mandatory TESTED/EVIDENCED gates (`08`).
Consequences: every compliance claim in any pitch/CV/portfolio context
must be traceable to an EVIDENCED-or-higher register row, never inferred
from DESIGNED/IMPLEMENTED status.

**ADR-010 — Saga pattern (not a single distributed transaction) for
Organization Provisioning**
Status: Proposed. Context: provisioning spans many domains without a
shared transaction boundary. Decision: step-tracked, compensable saga
(`11`). Consequences: a failed provisioning run is always resumable or
fully compensable, never left in an ambiguous half-created state.

**ADR-011 — Tiered documentation depth for the Domain Map and Workflow
Map**
Status: Proposed. Context: full 15-field depth for all 40 domains and 30
workflows in one pass is a documentation-effort trade-off. Decision:
Tier 1 (highest blast-radius) gets full depth; Tier 2 gets
complete-but-compact depth, expandable on request (`03`, `05`).
Consequences: no domain or workflow is left with an empty field, but not
every one has been explored to maximum depth yet — expansion is a
tracked, not a hidden, gap.

**ADR-012 — RPO/RTO numeric targets deferred pending business
continuity sign-off**
Status: Proposed. Context: inventing specific numbers would violate Zero
Fabrication. Decision: record recovery *mechanism* per component now;
numeric targets marked TBD until sign-off (`17`). Consequences: this
document set is honest about an real open gap rather than papering over
it with plausible-looking numbers.

**ADR-013 — NFR targets sourced from the project's own vision material,
explicitly labeled unmeasured**
Status: Proposed. Context: the vision material already states
aspirational figures (99.95%+ availability, <2s p95, etc.). Decision:
record them as targets, not measurements (`18`). Consequences: any future
dashboard must visually distinguish target-vs-measured to avoid
Zero-Fabrication drift.

**ADR-014 — Java/Spring Boot/PostgreSQL stack baseline for this pass**
Status: Proposed — **RESOLVED by ADR-019** (`docs/adr/ADR-019-RECONCILIATION-WITH-ADR-000.md`,
2026-08-27). Context: this master foundation's own prompt specifies Java
25 LTS / Spring Boot 4.1 / Spring Modulith / PostgreSQL 18 (`14`); a prior
architecture consultation for this same project specified a different
Java version and left the Kotlin/Spring-Boot-vs-NestJS choice open — and,
separately, an existing governing document (`ADR-000`, the
`argon-platform-target-architecture` skill, dated 2026-08-22) already
established that ARGON's live Firebase system evolves only via staged,
trigger-based migration, never a big-bang rewrite. Decision: this
document set's Java 25/Spring Boot baseline is retained as the *updated
technical content* of ADR-000's North Star, but is now explicitly
subordinate to ADR-000's Staged Trigger Table and AI Agent Rules — see
ADR-019 for the full reconciliation, including why a 2026-08-23 blocked/
defective rebuild attempt on an earlier version of this same stack makes
ADR-000's staging discipline non-optional. Consequences: no phase of
`20-MASTER-IMPLEMENTATION-ROADMAP.md` may be treated as authorized to
start merely because it exists in this document set — each phase now
carries an explicit ADR-000 trigger cross-reference.

**ADR-015 — Digital provisioning ≠ legal/regulatory approval**
Status: Proposed. Context: a Control Plane "Activate" action must never
be mistaken for a government license or inspection pass. Decision:
explicit non-scope statement in `11`; Organization ACTIVE state means
digital readiness only. Consequences: every pitch/customer-facing
description of "provision a hospital in minutes" must carry this caveat.

---

### Full-Format ADRs (2026-08-27 Architecture Normalization Pass)
*The three entries below follow the fuller ADR template required by the
Architecture Normalization task (ADR ID, Title, Status, Date, Context,
Problem, Options, Evidence, Decision, Rationale, Consequences, Security/
Operational/Compliance Impact, Revisit Trigger, Rollback/Exit Strategy).
ADR-001–ADR-015 above remain in the lightweight format pending a full
reformat pass — tracked as open work, not silently upgraded.*

**ADR-016 — Internal event backbone: Google Cloud Pub/Sub (primary),
RabbitMQ (conditional), Kafka (rejected)**
- Status: **PROPOSED** (not Approved — requires sign-off per ADR-009's
  discipline applied to itself)
- Date: 2026-08-27
- Context: `06`'s original target named RabbitMQ as the sole internal
  event backbone. The Architecture Normalization task required a fresh,
  non-popularity-based comparison against Google Cloud Pub/Sub and Apache
  Kafka.
- Problem: Which messaging technology should back the Transactional
  Outbox pattern for a single-team-operated, GCP-native platform at its
  current stage?
- Options: RabbitMQ (self/managed), Google Cloud Pub/Sub (managed),
  Apache Kafka (self-managed or Confluent).
- Evidence: `docs/evidence/TECHNOLOGY-BASELINE-VERIFICATION.md` §5 (live
  research, 2026-08-27).
- Decision: Pub/Sub primary; RabbitMQ conditional (AMQP-only external
  adapters only); Kafka rejected for the current stage.
- Rationale: Pub/Sub eliminates broker/partition operational burden
  entirely on a platform that is already GCP-first end to end (`13`);
  no evidenced requirement justifies Kafka's added operational
  complexity; RabbitMQ remains available where a specific external
  system requires AMQP.
- Consequences: `06`'s Internal Event Backbone section and `14`'s Data
  table are both updated; the domain layer depends on a messaging
  abstraction, not a broker SDK, keeping this reversible.
- Security Impact: Pub/Sub inherits GCP IAM scoping natively; no new
  broker-credential surface to manage versus a self-hosted RabbitMQ.
- Operational Impact: Removes cluster/broker management from the
  platform-ops workload entirely for the primary path.
- Compliance Impact: None identified; data-residency implications of
  Pub/Sub (regional topic placement) should be checked per country
  during Phase 6 (`20`) alongside the Government Country Adapter work.
- Revisit Trigger: A measured requirement for cross-partition ordering
  at platform scale, or a real long-window event-replay/event-sourcing
  need beyond Pub/Sub's 31-day maximum retention.
- Rollback/Exit Strategy: Because domain code depends on the messaging
  abstraction rather than the Pub/Sub SDK, swapping the underlying
  transport (including back to RabbitMQ or to Kafka) is an
  infrastructure-and-adapter change, not a domain-code rewrite.

**ADR-017 — Infrastructure as Code: OpenTofu (replacing Terraform)**
- Status: **PROPOSED**
- Date: 2026-08-27
- Context: `13`/`14`'s original target named Terraform. The Architecture
  Normalization task explicitly listed "Terraform vs OpenTofu" as a
  drift category to verify with fresh evidence.
- Problem: Which IaC tool should the platform standardize on, given
  Terraform's 2023 relicensing to BSL 1.1 and IBM's 2024 acquisition of
  HashiCorp?
- Options: Terraform (BSL 1.1, IBM-owned), OpenTofu (MPL 2.0, Linux
  Foundation-governed fork).
- Evidence: `docs/evidence/TECHNOLOGY-BASELINE-VERIFICATION.md` §6 (live
  research, 2026-08-27).
- Decision: OpenTofu adopted as the IaC baseline.
- Rationale: OSI-approved MPL 2.0 licensing reduces legal-review friction
  for a healthcare platform expecting ongoing compliance/legal review
  (`08`); native state/plan encryption is a concrete security
  improvement over Terraform's open CLI; HCL syntax and provider
  ecosystem are near-identical, keeping migration risk low; no
  Terraform-exclusive feature (e.g., HCP Terraform Stacks) is required
  by anything in this architecture today.
- Consequences: `13`'s Infrastructure Diagram section and `14`'s
  Observability & Infrastructure table both updated; Terraform state
  language throughout `13`/`17` updated to OpenTofu state.
- Security Impact: Native state encryption directly strengthens the
  Terraform-state DR/security posture already tracked in `17`.
- Operational Impact: Near-zero — CLI and workflow are effectively a
  binary swap (`terraform` → `tofu`).
- Compliance Impact: Improves license-review posture for regulated
  jurisdictions (`08`).
- Revisit Trigger: A specific need for an HCP-Terraform-exclusive
  capability, or evidence of GCP-provider compatibility regression in
  OpenTofu.
- Rollback/Exit Strategy: Both tools read the same state format as of
  this writing; a "dual-engine" fallback (Terraform CLI against the same
  state) remains available without a state migration if ever needed.

**ADR-018 — FHIR production baseline corrected to R4/R4B (was R5)**
- Status: **PROPOSED** (correction, not yet independently reviewed)
- Date: 2026-08-27
- Context: The original `06`/`14` target stated FHIR R5 as the
  production baseline with R4/R4B as a compatibility layer. The
  Architecture Normalization task required re-verifying this against
  current official/authoritative sources rather than carrying it forward
  unverified.
- Problem: Is R5 actually the correct production target for near-term
  real-world interoperability (government systems, payers, external
  labs)?
- Options: R4/R4B as baseline (R5 optional), R5 as baseline (R4/R4B
  compatibility), R6 as baseline (rejected outright — still in ballot).
- Evidence: `docs/evidence/TECHNOLOGY-BASELINE-VERIFICATION.md` §10 (live
  research, 2026-08-27): US Core (the dominant regulatory FHIR baseline)
  remains on R4 and is not planning to move to R5; R5 is independently
  described as having limited real-world adoption; R6 is still in ballot
  (first full ballot dated May 2026), with production-grade adoption not
  expected before late 2027 per HL7's own guidance.
- Decision: FHIR R4/R4B is now the stated production target; R5 is
  transitional/optional (adopted only per specific partner requirement);
  R6 is tracked, not adopted.
- Rationale: Matches the regulatory and ecosystem reality found in fresh
  research rather than an earlier, unverified assumption that R5 was the
  more "current" and therefore preferable choice.
- Consequences: This is a **documentation correction**, not a scope
  change — no domain/workflow document required rewriting beyond the
  `06`/`14` version labels, since the canonical internal clinical model
  (`Clinical` domain, `03`) was never FHIR-native in the first place.
- Security Impact: None identified.
- Operational Impact: None identified at this design stage.
- Compliance Impact: Directly improves alignment with the dominant
  regulatory FHIR baseline (US Core / ONC Cures Act / CMS), reducing
  future integration-conformance risk.
- Revisit Trigger: FHIR R6 reaching final/normative publication.
- Rollback/Exit Strategy: N/A — this is itself the correction of an
  earlier, unverified claim; there is no prior "implementation" to roll
  back.

**ADR-019 — Reconciliation with ADR-000 (ARGON Platform Target
Architecture & Migration Strategy)**
- Status: **PROPOSED**
- Date: 2026-08-27
- Context: An existing, previously-established governing document
  (`ADR-000`, `argon-platform-target-architecture` skill, dated
  2026-08-22, "Accepted as North Star") already reconciles ARGON's
  long-term vision against `argon-governance`'s "reality over ambition"
  principle via a Staged Trigger Table, a "build now" list, and explicit
  AI Agent Rules against proposing a Firebase migration without a fired
  trigger. This entire v2/v3 `docs/` tree (ADR-014) was authored without
  referencing it. Separately, a real rebuild attempt on 2026-08-23 — three
  days prior, on an earlier version of this same stack — was found
  blocked with a non-functional build environment and a forensic audit
  finding real code defects.
- Decision: ADR-000 remains the governing document unchanged; this
  document set's technology baseline supersedes ADR-000's inherited
  NestJS reference as updated technical content only; every phase in
  `20-MASTER-IMPLEMENTATION-ROADMAP.md` is re-gated by ADR-000's trigger
  table; a new permanent build-verification-before-implementation-claim
  gate (Rule L15) is added, sourced directly from the 2026-08-23 failure;
  the live Firebase system remains the sole production system.
- Full detail: `docs/adr/ADR-019-RECONCILIATION-WITH-ADR-000.md`.
- Consequences: ADR-014 is now marked RESOLVED. No implementation is
  authorized by this reconciliation — the next real, low-risk step
  toward the vision is ADR-000's own "build now" list, inside the
  existing Firebase schema, not this stack.
- Revisit Trigger: Any ADR-000 trigger-table row firing for the first
  time.

**ADR-020 — Deliberate Freeze Exception: Gap Analysis Pass (2026-09-02)**
- Status: **PROPOSED**
- Date: 2026-09-02
- Context: `docs/governance/ARCHITECTURE-FREEZE.md` defines exactly five
  valid triggers for reopening the frozen baseline (security
  vulnerability, regulatory/legal change, technology EOL/critical
  change, measured production evidence, material new requirement). A
  request for a full gap-analysis-and-completion pass across the entire
  repository was made without citing any of the five. This was raised
  explicitly to the requester before proceeding.
- Decision: The requester, informed of the freeze and the five-trigger
  rule, made a conscious, explicit choice to proceed anyway: "نفذ الـ
  Gap Analysis كاملة واعياً إنه فتح للتجميد" ("execute the gap analysis
  fully, aware this reopens the freeze"). This ADR records that
  choice as the deliberate exception it is, rather than either (a)
  silently treating a sixth "final" pass as routine, or (b) refusing a
  repository owner's explicit, informed decision about their own
  project.
- Rationale: A freeze process that cannot be consciously overridden by
  its own owner is not governance, it's a lock without a key. The
  discipline that matters is that the override is *logged and
  reasoned*, not that it never happens.
- Consequences: `docs/audit/FINAL-GAP-ANALYSIS.md`,
  `docs/audit/FINAL-GAP-REGISTER.md`, `docs/audit/DO-NOT-BUILD-YET.md`,
  and `docs/audit/FINAL-IMPLEMENTATION-READINESS.md` are added under
  this exception. **This ADR does not re-open the freeze generally** —
  `docs/governance/ARCHITECTURE-FREEZE.md` remains in force for every
  future request; each future exception requires its own explicit,
  logged instance of this same conscious choice, not a standing license
  to keep analyzing indefinitely.
- Security/Operational/Compliance Impact: None — this pass adds
  analysis documents only, per the originating task's own Section 30
  Hard Stop Rule (no implementation, no Firebase migration, no
  infrastructure deployment, no production change).
- Revisit Trigger: N/A — this ADR documents a single, dated exception
  event.
- Rollback/Exit Strategy: N/A — no implementation occurred.

**ADR-021 — Consent Ownership Reconciliation: Consent domain is sole write-owner (2026-09-08)**
- Status: **PROPOSED**
- Date: 2026-09-08
- Context: A deep structural connectivity audit found `ConsentRecord`
  independently owned by both PATIENT (`RecordConsent`/`ConsentChanged`)
  and CONSENT (`CaptureConsent`/`WithdrawConsent`/`ConsentGranted`/
  `ConsentWithdrawn`) in `03-MASTER-DOMAIN-MAP.md` — two non-overlapping
  command/event vocabularies for the same entity, with no delegation
  language in either direction. Recorded as ACR-1 in
  `docs/audit/DEEP-CONNECTIVITY-RECONCILIATION.md` and
  `docs/audit/ACR-RESOLUTION-OPTIONS.md`.
- Decision: The repository owner selected Option A. CONSENT becomes the
  sole owner of the consent write lifecycle. PATIENT retains only a
  read-side delegation (`GetConsentStatus` reads through to CONSENT) and
  no longer declares `ConsentRecord`, `RecordConsent`, or
  `ConsentChanged` as its own.
- Decision Provenance: This resolution (Option A) was explicitly
  directed by the repository owner in the governing project
  conversation for this repository. This is a record of that direction,
  not a formal ADR approval — Status remains PROPOSED until the
  repository owner (or whatever future mechanism `DECISION-AUTHORITY.md`
  establishes) formally approves it through this document's own change
  process.
- Rationale: CONSENT already carried structured detail (`ConsentScope`,
  `WithdrawalRecord`, explicit "checked by every domain... before any
  external share" framing) that PATIENT's competing definition lacked.
  Removing a two-command surface from PATIENT is a smaller, more
  contained change than reproducing CONSENT's detail inside PATIENT.
- Consequences: `03-MASTER-DOMAIN-MAP.md`'s PATIENT and CONSENT entries
  updated to reflect this split. Workflow #1 (Patient Registration) in
  `05-MASTER-WORKFLOW-MAP.md` was updated to replace its stale
  Patient-owned consent reference (`ConsentRecord (Patient domain)`)
  and event (`ConsentChanged`) with the correct Consent-domain
  boundary (`CaptureConsent`/`ConsentGranted`).
- Security/Operational/Compliance Impact: None negative — consolidates
  consent enforcement (compliance-critical per `08`) into a single
  domain instead of two competing surfaces, which reduces the risk of
  one being checked while the other is bypassed.
- Revisit Trigger: If a future implementation pass finds PATIENT's app
  layer needs its own consent-write UI flow, that flow must still call
  through to CONSENT's commands — it does not reopen this ADR.
- Rollback/Exit Strategy: N/A — no implementation occurred; this is a
  documentation-level correction of the target architecture only.

**ADR-022 — Claim Ownership Reconciliation: Claims domain owns submission, Insurance retains adjudication/remittance (2026-09-08)**
- Status: **PROPOSED**
- Date: 2026-09-08
- Context: The same audit found `Claim` independently owned by both
  INSURANCE (`SubmitClaim`, `ClaimSubmitted`) and CLAIMS
  (`SubmitClaim` — an identically named command — plus `AssembleClaim`/
  `TrackStatus`, and `ClaimAssembled`/`ClaimSubmitted`/`ClaimDenied`/
  `ClaimPaid`). CLAIMS's own Purpose line already described itself as
  owning this sub-lifecycle "within Insurance," but INSURANCE's command
  list was never updated to reflect that. Recorded as ACR-2.
- Decision: The repository owner selected Option A, precisely scoped:
  CLAIMS becomes sole owner of the claim submission lifecycle
  (`Claim` entity, `SubmitClaim` command, `ClaimSubmitted` event).
  INSURANCE explicitly **retains** eligibility, authorization,
  adjudication (`ClaimAdjudicated` — which was never actually
  duplicated between the two domains), and remittance reconciliation.
- Decision Provenance: This resolution (Option A, with the precise
  Insurance-retains-adjudication scoping) was explicitly directed by
  the repository owner in the governing project conversation for this
  repository. This is a record of that direction, not a formal ADR
  approval — Status remains PROPOSED until the repository owner (or
  whatever future mechanism `DECISION-AUTHORITY.md` establishes)
  formally approves it through this document's own change process.
- Rationale: `ClaimAdjudicated` was confirmed, on re-reading both
  entries directly, to be uniquely an Insurance event — CLAIMS has
  `ClaimDenied`/`ClaimPaid` as adjudication *outcomes*, not a
  duplicate of `ClaimAdjudicated` itself. The only genuine duplicates
  were the `Claim` entity, the `SubmitClaim` command, and the
  `ClaimSubmitted` event — so the fix is narrower than a full split of
  all claim-related responsibility, matching the owner's explicit
  instruction that Insurance keeps adjudication.
- Consequences: `03-MASTER-DOMAIN-MAP.md`'s INSURANCE and CLAIMS entries
  updated. `05-MASTER-WORKFLOW-MAP.md` workflow #10 (Insurance & Claims)
  updated to attribute the assemble/submit steps to Claims' commands and
  the eligibility/authorization/adjudication/remittance steps to
  Insurance's, where the prior text left this ambiguous.
- Security/Operational/Compliance Impact: None negative — coding-attached
  claim submission (compliance-critical for payer contracts per `03`'s
  CLAIMS entry) stays exclusively in the domain built to enforce the
  coding-discrepancy test (`03` CLAIMS Tests field), rather than being
  reachable via two separate command surfaces with different guard rails.
- Revisit Trigger: If Insurance's `GetClaimStatus` query (still present
  in both INSURANCE and CLAIMS as a read-only query, not flagged as part
  of this ACR) is found to diverge in behavior between the two domains
  during implementation, that is a new finding requiring its own ADR —
  it is explicitly out of scope for this one.
- Rollback/Exit Strategy: N/A — documentation-level only.

**ADR-023 — Payment Ownership Reconciliation: Payments owns the gateway transaction, Billing owns the ledger entry (2026-09-08)**
- Status: **PROPOSED**
- Date: 2026-09-08
- Context: The same audit found BILLING independently declaring
  `Payment`/`RecordPayment`/`PaymentReceived` with direct payment-gateway
  integration, while PAYMENTS independently declared
  `PaymentTransaction`/`RefundTransaction`/`CapturePayment`/`IssueRefund`/
  `PaymentCaptured` with its own direct gateway integration, idempotency
  handling, and PCI DSS tokenization detail BILLING lacked entirely. A
  prior session pass had edited only `05`'s workflow narrative to assume
  a delegation to Payments, without correcting `03`'s BILLING entry —
  meaning the underlying domain-map conflict was never actually
  resolved, only masked in one downstream document. Recorded as ACR-5
  (originally surfaced as a Cloud #2-reported finding, independently
  re-verified against `03` directly before this ADR was written).
- Decision: The repository owner selected Option C — a two-layer split,
  not a full removal of `Payment` from Billing. PAYMENTS owns
  `PaymentTransaction`, `RefundTransaction`, all gateway interaction,
  idempotency, and tokenization — the transaction lifecycle in full.
  BILLING keeps `Payment` but redefined as a ledger/accounting posting
  record only; `PaymentTransaction` and `Payment` are explicitly
  declared distinct objects. PAYMENTS emits `PaymentCaptured`; BILLING
  consumes that event and performs its own ledger posting
  (`RecordPayment`) in reaction — Billing is explicitly prohibited from
  being gateway-facing or a second source of truth for the transaction.
- Decision Provenance: This resolution (Option C, the two-layer split)
  was explicitly directed by the repository owner in the governing
  project conversation for this repository. This is a record of that
  direction, not a formal ADR approval — Status remains PROPOSED until
  the repository owner (or whatever future mechanism
  `DECISION-AUTHORITY.md` establishes) formally approves it through
  this document's own change process.
- Rationale: This preserves Billing's existing ledger/accounting
  vocabulary (avoiding a wholesale rewrite of its financial-ledger
  framing) while eliminating the actual defect — two domains each
  claiming direct gateway ownership. Workflow #9 (Billing) in `05` was
  updated to encode the Payments transaction boundary explicitly —
  `PaymentCaptured` → Billing ledger posting, and the removal of
  Billing's direct gateway role — since the workflow's prior text had
  already (prematurely, and without this precise boundary) assumed some
  form of Payments delegation.
- Consequences: `03-MASTER-DOMAIN-MAP.md`'s BILLING and PAYMENTS entries
  updated; `05-MASTER-WORKFLOW-MAP.md` workflow #9 (Billing) updated to
  match the ledger/transaction split precisely (previously it read as
  if already delegated, but without the ledger-vs-transaction
  distinction this ADR establishes). A new Billing test was added
  (`DENY any Billing code path that calls a payment gateway directly`)
  mirroring the existing cross-domain-write guard-rail pattern already
  used elsewhere in `03` (e.g. the AI/Clinical guard rail).
- Security/Operational/Compliance Impact: Positive — narrows PCI DSS
  scope to the Payments domain exclusively (Billing never touches
  gateway or tokenized card detail), which is a cleaner compliance
  boundary than either domain independently integrating the gateway.
- Revisit Trigger: If a future implementation pass finds the
  ledger-posting reaction to `PaymentCaptured` needs its own
  idempotency handling distinct from Payments' (e.g. duplicate-event
  delivery), that is a new, narrower architectural question — not a
  reopening of this ADR's ownership split.
- Residual/Revisit Note — Refunds: This ADR does not decide the exact
  relationship between a Payments-domain refund transaction
  (`RefundTransaction`/`IssueRefund`/`RefundIssued` — the actual gateway
  refund) and a Billing-domain `CreditNote`/`IssueCreditNote`/
  `CreditNoteIssued` (the accounting treatment). Both remain owned
  exactly where they already were before this ADR — Payments owns the
  refund transaction, Billing owns the credit note — and this ADR does
  not assert, require, or imply any fixed mapping in either direction
  (e.g. `RefundIssued` does not automatically produce a
  `CreditNoteIssued`, nor does a `CreditNote` imply a
  `RefundTransaction`). Whether and how these two should be linked is
  an open semantic question for a future decision, not resolved here.
- Rollback/Exit Strategy: N/A — documentation-level only; no
  implementation occurred.

**ADR-024 — Object Storage Retrieval Credential Boundary (2026-09-16)**
- Status: **PROPOSED**
- Date: 2026-09-16
- Decision Question: May ARGON issue an object-storage retrieval
  credential that is redeemable outside ARGON's own authorization
  boundary (i.e., checked and honored by the storage provider directly,
  without a request reaching an ARGON-controlled service at redemption
  time)?
- Context: `03` DOCUMENTS already owns access-controlled retrieval
  (`Retrieve`), depends on both Object Storage and Consent, and
  requires every retrieval logged with denial outside the owning
  record's access scope. `03` RADIOLOGY defines the imaging lifecycle
  (`PlaceImagingOrder`, `ScheduleStudy`, `AcquireImages`,
  `FinalizeReport`, `FlagCriticalFinding`) and requires "every study
  access... audited," but currently declares no retrieval command or
  query and no dependency on Documents or Consent — the audit
  requirement has no operation to attach to. `04` places DICOM
  instances in object storage rather than PostgreSQL. `06` establishes
  the Interoperability Layer, including a DICOMweb Gateway, as the sole
  choke point for external protocol traffic. `07` establishes
  workload-scoped service identity (no static service keys) and the
  application → authorization service → RLS model, and separately
  states that session revocation is server-side and takes effect
  immediately rather than at next token expiry — a property stated for
  sessions, not evaluated here for storage credentials. `13` names Cloud
  SQL and Memorystore as never publicly reachable within the private
  network, and lists Cloud Storage as an infrastructure component
  without including it in that same network-boundary statement — an
  omission, not a stated decision either way. No document in this
  repository specifies a mechanism by which retrieval credentials are
  issued, delivered, or redeemed for protected object-storage content.
- Options Considered:
  - **Option A — Provider-native signed URL.** The storage provider
    validates and redeems the credential directly; ARGON is not on the
    path at redemption time. Cannot consult ARGON consent state at
    redemption. Revocation is bounded by credential expiry, not
    immediate. Avoids routing binary transfer through the application
    tier, which matters at DICOM study scale (many instances per
    study).
  - **Option B — Opaque application-mediated credential.** Redemption
    is a request to an ARGON-controlled service, which can check
    consent state and authorization at redemption time and revoke
    before expiry. Still requires a delivery mechanism for the
    underlying bytes, and does not by itself resolve DICOM study-scale
    transfer.
  - **Option C — Authenticated application proxy/stream.** Every byte
    of every retrieval passes through an ARGON-controlled service.
    Strongest redemption-time enforcement; the application tier carries
    the full bandwidth of every retrieval, including full DICOM
    studies.
  - **Option D — Hybrid.** Different content classes or risk levels use
    different options above. Consequences depend entirely on which
    content maps to which option, which this ADR does not specify.
  - This document evaluates architectural consequences only; it does
    not rank the options by preference, cost, or convenience.
- Architecturally Achievable Security Properties by Option (this table
  describes what each option would make architecturally possible if
  built, not what is already implemented — no object-storage credential
  mechanism exists yet; see Rollback/Exit Strategy below):

  | Property | A | B | C | D |
  |---|---|---|---|---|
  | Tenant isolation | UNKNOWN | PRESENT | PRESENT | depends on split |
  | Authorization enforcement at redemption | MISSING | PRESENT | PRESENT | depends on split |
  | Consent-state enforcement at redemption | MISSING | PRESENT | PRESENT | depends on split |
  | Revocation before expiry | MISSING | PRESENT | PRESENT | depends on split |
  | Replay resistance | UNKNOWN | PRESENT | PRESENT | depends on split |
  | Object enumeration resistance | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN |
  | Audit visibility at actual access | MISSING (issuance only) | PRESENT | PRESENT | depends on split |
  | Credential leakage exposure | UNKNOWN | UNKNOWN | UNKNOWN | UNKNOWN |
  | DICOM study-scale viability | REQUIRES MEASUREMENT | REQUIRES MEASUREMENT | REQUIRES MEASUREMENT | REQUIRES MEASUREMENT |
  | Direct object-store exposure | inherent to the mechanism | avoidable | avoided | depends on split |

  No entry above reflects a control this repository does not already
  describe elsewhere or a control invented for this ADR. Tenant
  isolation and replay resistance for Option A are marked UNKNOWN rather
  than assessed, because no document in this repository addresses
  either property for a provider-native signed credential — the
  repository's replay-related evidence (refresh-token reuse detection,
  event-processing idempotency) concerns different mechanisms entirely.
  Credential leakage exposure is marked UNKNOWN across all options for
  the same reason: no document establishes a measurable basis for
  comparing leakage risk between a bearer URL, an opaque token, and a
  proxy session. DICOM study-scale viability is marked REQUIRES
  MEASUREMENT across all options, since no transfer-duration or
  instance-count data exists in this repository to support even a
  qualitative comparison; `06`'s Interoperability Layer establishes
  that a DICOMweb Gateway exists, but not how it performs at scale
  under any of these options. Object enumeration resistance remains
  UNKNOWN for all options, as before.
- Direct Access Clarification: Under every option, the *initial*
  authorization request — deciding whether this identity, for this
  tenant, may access this object at all — occurs through ARGON's
  authorization service. The options diverge after that point. Under
  Option A, once the signed credential is issued, *redemption* (the
  actual retrieval of bytes) is handled directly by the storage
  provider — outside ARGON's authorization boundary, with no further
  ARGON-controlled check between issuance and delivery. Under Options B
  and C, redemption itself is a request to an ARGON-controlled service,
  so ARGON's authorization boundary extends through to the moment of
  access, not merely to issuance. "Cloud Storage is an
  internet-addressable service" does not by itself mean unauthorized
  clients can reach protected content directly — that initial check
  exists under every option. The architectural question this ADR
  presents is precisely whether allowing redemption to occur outside
  ARGON's boundary (as in Option A) is acceptable for this content
  class, or whether redemption must remain inside it (as in Options B
  and C).
- Decision (PROPOSED): Protected object-storage retrieval credentials
  must not be redeemable outside an ARGON-controlled authorization
  boundary. Option A (provider-native signed URL, redeemed directly by
  the storage provider with no further ARGON-controlled checkpoint) is
  therefore not permitted for protected content. This preserves the
  ability to enforce authorization and consent-related checks at the
  moment of redemption, not only at issuance — the property Option A
  cannot provide (see Security Properties by Option, above). This
  decision selects the authorization-boundary requirement only. It does
  **not** select a byte-delivery mechanism: whether the specific
  implementation is Option B (opaque application-mediated credential),
  Option C (authenticated proxy/stream), or a hybrid, and whether
  underlying bytes are proxied through the application tier in full or
  delivered by some other ARGON-controlled means, remains a separate
  implementation/design question subject to DICOM-scale performance
  measurement (see Security Properties by Option, "DICOM study-scale
  viability: REQUIRES MEASUREMENT," and Explicitly Out of Scope, below).
  `authorization-boundary control under ARGON` and `mandatory full
  application-tier byte proxying` are two different questions; this
  decision resolves only the first.
- Decision Provenance: Repository-owner directed. The direction above
  reflects the repository owner's proposed decision, communicated
  directly, not an AI-selected recommendation. Per
  `docs/governance/DECISION-AUTHORITY.md`, an owner-directed proposal
  does not constitute approval: this ADR remains **PROPOSED** until the
  formal approval process in `docs/governance/ARCHITECTURE-FREEZE.md`
  is completed, and no implementation has started or is authorized by
  this entry.
- Explicitly Out of Scope for This ADR (deferred, not decided here):
  credential lifetime/TTL (an implementation parameter subject to
  future measurement, not fixed by this document); the required
  business/legal revocation latency after `ConsentWithdrawn` (a
  business/legal decision, not an architectural one); object-version
  retention, anonymization-vs-erasure interaction, and legal-hold
  interaction for versioned object storage (a separate, later
  decision); the exact byte-delivery mechanism and DICOM transfer
  performance (implementation/design questions subject to measurement,
  to be resolved within the boundary this ADR sets — not by this ADR
  itself); and the specific mechanism by which RADIOLOGY's "every
  study access audited" requirement gains a retrieval operation to
  attach to (an implementation/design consequence of whichever
  delivery mechanism is selected, requiring its own subsequent
  controlled resolution — not a new domain, workflow, or ownership
  assignment made by this ADR).
- Security/Operational/Compliance Impact: This ADR performs no
  implementation and changes no control by itself — no credential
  mechanism exists yet, so nothing in production is affected by this
  document alone. That is a statement about this document's own
  effect, not about the underlying question: the asymmetry it records
  (object storage lacking both the RLS backstop and the private-network
  treatment that PostgreSQL and Redis have) is a real, currently open
  security boundary, and RADIOLOGY's "every study access audited"
  requirement currently has no operation to attach to. Selecting an
  option is what will change a control; recording the decision here is
  what makes that future change subject to the same owner-approval
  process as any other frozen-baseline change, rather than an implicit
  default.
- Revisit Trigger: Option A is no longer available under this ADR; the
  authorization-boundary principle is decided. The remaining
  implementation/design space is Option B, Option C, or a hybrid
  compatible with that principle. This entry remains open until a
  specific byte-delivery mechanism is selected within that space, which
  requires DICOM-scale measurement (see Security Properties by Option,
  "DICOM study-scale viability: REQUIRES MEASUREMENT") where
  performance evidence bears on the choice.
- Rollback/Exit Strategy: N/A — no implementation occurred; this is a
  documentation-level decision record only.

## Alternatives Considered
Each ADR above already documents its own alternative(s) inline — this
document does not duplicate them a second time.

## Security Impact
ADR-007 and ADR-008 are this document's most security-relevant entries;
both are fully elaborated in `07`.

## Operational Impact
ADR-002, ADR-003, ADR-010 are the entries with the largest day-to-day
operational consequence.

## Performance Impact
No new performance claims — ADR-013 explicitly defers to `18`.

## Compliance Impact
ADR-009 and ADR-015 are this document's compliance-critical entries.

## Failure Modes
An ADR marked Proposed being treated as Accepted without an actual review
step is itself the failure mode ADR-009's discipline exists to prevent,
applied reflexively to this document.

## Dependencies
Synthesizes `01` through `18`. Feeds `20` (roadmap sequencing reflects
these decisions).

## Unknowns
UNKNOWN whether any of these ADRs have been reviewed/accepted by an
actual decision authority — this log is a record of what was decided in
this pass, not a claim of sign-off.

## Validation
Every "Alternatives Considered" section in `01`–`18` has a corresponding
ADR entry above. Confirmed at time of writing.

## Rollback
Any ADR here can be superseded by a later ADR that explicitly says so —
ADRs are never silently edited; a changed decision gets a new numbered
entry referencing the one it supersedes.

## Definition of Done
Every platform-wide decision referenced across `01`–`18` has exactly one
ADR entry above; no decision is documented in two places with
inconsistent framing.
