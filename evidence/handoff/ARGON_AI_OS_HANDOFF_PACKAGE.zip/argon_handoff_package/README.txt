ARGON AI-OS MASTER HANDOFF PACKAGE

READ FIRST:
01_MASTER_HANDOFF/ARGON_AI_OS_MASTER_HANDOFF_AR.md

This package preserves:
- Full Arabic master handoff with the current C1 execution state and continuation prompt.
- Full C2, C3, C4, C5, C6 future capability-pack prompts and C7 independent audit prompt.
- The common execution-discipline instruction.
- The two original ARGON Health HTML reference guides, separated and explicitly marked as a different project.
- The C2 canonical research file and manifest available in the current runtime, plus one available C7-FFA-003 copy.

IMPORTANT:
The package does NOT claim to contain all canonical C1-C6 source files. For C1 synthesis, the user must also attach the actual canonical C1-C6 files and relevant C7 audit copies/manifests if they are not included in this package. Old/superseded drafts must not replace canonical artifacts.
