## Change summary

## Requirement / ADR / risk links
- Requirement/control IDs:
- ADR or source-of-truth reference:
- Risks added, changed, or closed:

## Impact review
- [ ] Clinical workflow/safety impact assessed (or reasoned N/A).
- [ ] Patient data/privacy/jurisdiction impact assessed.
- [ ] Tenant isolation, authentication, authorization, and audit impact assessed.
- [ ] Schema/data migration and backward compatibility assessed.
- [ ] Integration contract, retries, idempotency, and partial failure assessed.
- [ ] Performance, availability, backup/restore, and rollback impact assessed.
- [ ] Telemetry checked for secrets and patient-identifying/clinical data.

## Verification evidence
- Tests run and exact commit/build:
- Evidence register IDs / artifact paths:
- Security/dependency/secret scan results where applicable:
- Known limitations or untested scope:

## Release safety
- [ ] No unsupported `PASS`, `VERIFIED`, `EVIDENCED`, `compliant`, `certified`, or `production-ready` claim.
- [ ] All failures and blocked checks are reported honestly.
- [ ] High-risk changes reviewed by appropriate independent owner(s).
- [ ] Rollback/forward-fix strategy documented if production-impacting.
